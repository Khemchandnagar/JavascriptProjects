const againstTime = document.getElementById("against-time"),
    multiplayer = document.getElementById("multiplayer"),
    againstComputer = document.getElementById("against-computer"),
    playButton = document.querySelector(".btn-for-option");


function showOptions() {
    if (againstTime.checked === true) {
        document.querySelector("#PAT").style.display = "flex";
        document.querySelector("#MTP").style.display = "none";
        document.querySelector("#PAC").style.display = "none";
        playButton.style.display = "flex";
    } else if (multiplayer.checked === true) {
        document.querySelector("#PAT").style.display = "none";
        document.querySelector("#MTP").style.display = "flex";
        document.querySelector("#PAC").style.display = "none";
        playButton.style.display = "flex";
    } else if (againstComputer.checked === true) {
        document.querySelector("#PAT").style.display = "none";
        document.querySelector("#MTP").style.display = "none";
        document.querySelector("#PAC").style.display = "flex";
        playButton.style.display = "flex";
    } else {
        document.querySelector("#PAT").style.display = "none";
        document.querySelector("#MTP").style.display = "none";
        document.querySelector("#PAC").style.display = "none";
        playButton.style.display = "none";
    }
}


function valueSender() {
    let time = document.getElementById("time-value").value;
    localStorage.setItem("time-value", time);
    window.location.href = "Game-files/game.html";
    let gridSize = document.getElementById("grid-value").value;
    localStorage.setItem("grid-value", gridSize);
    window.location.href = "Game-files/game.html";
}